
export const MARPLE_BASE = "http://localhost:8080";
